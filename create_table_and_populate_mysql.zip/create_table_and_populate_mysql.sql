-- Criação das tabelas para MySQL
DROP TABLE IF EXISTS relatorios_gerados, solicitacoes_relatorio, participacoes, professor_turma, atividades, turmas, professores, alunos;

CREATE TABLE alunos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome TEXT,
    email TEXT
);

CREATE TABLE professores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome TEXT,
    departamento TEXT
);

CREATE TABLE turmas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome TEXT
);

CREATE TABLE professor_turma (
    professor_id INT,
    turma_id INT,
    PRIMARY KEY (professor_id, turma_id),
    FOREIGN KEY (professor_id) REFERENCES professores(id),
    FOREIGN KEY (turma_id) REFERENCES turmas(id)
);

CREATE TABLE atividades (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome TEXT,
    tipo TEXT,
    turma_id INT,
    FOREIGN KEY (turma_id) REFERENCES turmas(id)
);

CREATE TABLE participacoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    aluno_id INT,
    atividade_id INT,
    turma_id INT,
    presenca BOOLEAN,
    horas DECIMAL(5,2),
    nota DECIMAL(4,2),
    conceito TEXT,
    status_avaliacao TEXT,
    FOREIGN KEY (aluno_id) REFERENCES alunos(id),
    FOREIGN KEY (atividade_id) REFERENCES atividades(id),
    FOREIGN KEY (turma_id) REFERENCES turmas(id)
);

-- Tabela para armazenar solicitações de relatórios
CREATE TABLE solicitacoes_relatorio (
    id INT AUTO_INCREMENT PRIMARY KEY,
    turma_id INT,
    tipo_relatorio VARCHAR(10) NOT NULL CHECK (tipo_relatorio IN ('excel', 'pdf')),
    status VARCHAR(20) NOT NULL DEFAULT 'pendente' CHECK (status IN ('pendente', 'processando', 'concluido', 'erro')),
    data_solicitacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    data_inicio_processamento TIMESTAMP NULL,
    data_conclusao TIMESTAMP NULL,
    erro_mensagem TEXT,
    usuario_solicitante VARCHAR(100) DEFAULT 'sistema',
    FOREIGN KEY (turma_id) REFERENCES turmas(id)
);

-- Tabela para armazenar relatórios gerados
CREATE TABLE relatorios_gerados (
    id INT AUTO_INCREMENT PRIMARY KEY,
    solicitacao_id INT,
    turma_id INT,
    tipo_relatorio VARCHAR(10) NOT NULL,
    nome_arquivo VARCHAR(255) NOT NULL,
    conteudo_arquivo LONGBLOB NOT NULL, -- Armazenar o arquivo como dados binários
    tamanho_bytes BIGINT,
    data_geracao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    metadados JSON, -- Para armazenar informações adicionais
    FOREIGN KEY (solicitacao_id) REFERENCES solicitacoes_relatorio(id) ON DELETE CASCADE,
    FOREIGN KEY (turma_id) REFERENCES turmas(id)
);

-- Inserção de dados básicos
INSERT INTO turmas (nome) VALUES ('Turma A');

-- Professores
INSERT INTO professores (nome, departamento) VALUES 
('Professor A', 'Matemática'),
('Professor B', 'História');

-- Relaciona professores à turma
INSERT INTO professor_turma (professor_id, turma_id) VALUES 
(1, 1),
(2, 1);

-- Procedure para inserir alunos em massa (substitui generate_series)
DELIMITER //
CREATE PROCEDURE InsertAlunos()
BEGIN
    DECLARE i INT DEFAULT 1;
    WHILE i <= 500 DO
        INSERT INTO alunos (nome, email) VALUES 
        (CONCAT('Aluno ', i), CONCAT('aluno', i, '@exemplo.com'));
        SET i = i + 1;
    END WHILE;
END //
DELIMITER ;

-- Executa a procedure para inserir alunos
CALL InsertAlunos();

-- Remove a procedure após uso
DROP PROCEDURE InsertAlunos;

-- Procedure para inserir atividades
DELIMITER //
CREATE PROCEDURE InsertAtividades()
BEGIN
    DECLARE i INT DEFAULT 1;
    WHILE i <= 20 DO
        INSERT INTO atividades (nome, tipo, turma_id) VALUES 
        (CONCAT('Atividade ', i), 
         CASE WHEN i % 2 = 0 THEN 'Prova' ELSE 'Trabalho' END, 
         1);
        SET i = i + 1;
    END WHILE;
END //
DELIMITER ;

-- Executa a procedure para inserir atividades
CALL InsertAtividades();

-- Remove a procedure após uso
DROP PROCEDURE InsertAtividades;

-- Procedure para inserir participações (substitui generate_series com random)
DELIMITER //
CREATE PROCEDURE InsertParticipacoes()
BEGIN
    DECLARE i INT DEFAULT 1;
    WHILE i <= 10000 DO
        INSERT INTO participacoes (
            aluno_id, atividade_id, turma_id, presenca, horas, nota, conceito, status_avaliacao
        ) VALUES (
            FLOOR(RAND() * 500 + 1), -- aluno_id aleatório entre 1 e 500
            FLOOR(RAND() * 20 + 1),  -- atividade_id aleatório entre 1 e 20
            1, -- turma_id fixo
            RAND() > 0.2, -- presença (80% de chance de estar presente)
            ROUND(RAND() * 5, 2), -- horas aleatórias entre 0 e 5
            ROUND(RAND() * 10, 2), -- nota aleatória entre 0 e 10
            ELT(FLOOR(RAND() * 5 + 1), 'A', 'B', 'C', 'D', 'E'), -- conceito aleatório
            ELT(FLOOR(RAND() * 3 + 1), 'Aprovado', 'Reprovado', 'Pendente') -- status aleatório
        );
        SET i = i + 1;
    END WHILE;
END //
DELIMITER ;

-- Executa a procedure para inserir participações
CALL InsertParticipacoes();

-- Remove a procedure após uso
DROP PROCEDURE InsertParticipacoes;

-- Índices para melhorar performance
CREATE INDEX idx_participacoes_aluno ON participacoes(aluno_id);
CREATE INDEX idx_participacoes_atividade ON participacoes(atividade_id);
CREATE INDEX idx_participacoes_turma ON participacoes(turma_id);
CREATE INDEX idx_solicitacoes_turma ON solicitacoes_relatorio(turma_id);
CREATE INDEX idx_relatorios_solicitacao ON relatorios_gerados(solicitacao_id);
